import EditMode from './EditMode'

export default interface CartState {
  editMode: EditMode | null
}
