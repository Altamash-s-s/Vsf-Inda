---
name: Feature request
about: Suggest an idea for this project
labels: feature request

---

## What is the motivation for adding/enhancing this feature?
<!-- Describe the motivation or the concrete use case for a new feature or why one of the current ones should be enhanced. -->


## What are the acceptance criteria?
<!-- List the acceptance criteria for this task in the form of a list. -->

- [ ] ...

## Can you complete this feature request by yourself?

- [ ] YES
- [ ] NO

## Additional information
<!-- If you think that any additional information would be useful, please provide them here. -->

